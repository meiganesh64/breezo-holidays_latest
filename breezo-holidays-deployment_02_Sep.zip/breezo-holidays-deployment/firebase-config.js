// ============================================
// Firebase Configuration
// ============================================
// INSTRUCTIONS: Replace the values below with your Firebase project config.
// 
// To get your config:
// 1. Go to https://console.firebase.google.com
// 2. Create a new project (or use existing)
// 3. Click the gear icon → Project Settings
// 4. Scroll to "Your apps" → Click "Add app" → Choose Web (</>)
// 5. Register your app and copy the firebaseConfig object
// 6. Go to Firestore Database → Create Database → Start in test mode
//
// Then paste your values below:

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// Initialize Firebase
let db = null;
try {
  if (typeof firebase !== 'undefined' && firebaseConfig.apiKey !== "YOUR_API_KEY") {
    firebase.initializeApp(firebaseConfig);
    db = firebase.firestore();
    console.log('✅ Firebase initialized successfully');
  } else {
    console.warn('⚠️ Firebase not configured. Enquiry form will work in demo mode (data logged to console).');
  }
} catch (error) {
  console.error('❌ Firebase initialization error:', error);
}
