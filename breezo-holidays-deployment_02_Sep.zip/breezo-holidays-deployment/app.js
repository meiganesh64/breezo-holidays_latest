﻿// ============================================
// Breezo Holidays — Main Application Logic
// ============================================

document.addEventListener('DOMContentLoaded', () => {
  initNavbar();
  initMobileNav();
  initScrollReveal();
  initStatsCounter();
  initDestinationTabs();
  initEnquiryForm();
  initSmoothScroll();
  initHeroSlider();
  setMinDate();
});

// ============================================
// NAVBAR — Scroll effect
// ============================================
function initNavbar() {
  const navbar = document.getElementById('navbar');
  let lastScroll = 0;

  window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    if (currentScroll > 50) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
    lastScroll = currentScroll;
  }, { passive: true });
}

// ============================================
// MOBILE NAV — Toggle menu
// ============================================
function initMobileNav() {
  const toggle = document.getElementById('navToggle');
  const navLinks = document.getElementById('navLinks');
  const overlay = document.getElementById('mobileOverlay');

  function closeMenu() {
    toggle.classList.remove('active');
    navLinks.classList.remove('open');
    overlay.classList.remove('active');
    document.body.style.overflow = '';
  }

  function openMenu() {
    toggle.classList.add('active');
    navLinks.classList.add('open');
    overlay.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  toggle.addEventListener('click', () => {
    if (navLinks.classList.contains('open')) {
      closeMenu();
    } else {
      openMenu();
    }
  });

  overlay.addEventListener('click', closeMenu);

  // Close on link click
  navLinks.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', closeMenu);
  });

  // Close on escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeMenu();
  });
}

// ============================================
// SMOOTH SCROLL — Anchor links
// ============================================
function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        target.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });
}

// ============================================
// SCROLL REVEAL — Fade-in on scroll
// ============================================
function initScrollReveal() {
  const reveals = document.querySelectorAll('.reveal');

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.1,
    rootMargin: '0px 0px -40px 0px'
  });

  reveals.forEach(el => observer.observe(el));
}

// ============================================
// STATS COUNTER — Animated count up
// ============================================
function initStatsCounter() {
  const statNumbers = document.querySelectorAll('.stat-number[data-target]');

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        animateCounter(entry.target);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });

  statNumbers.forEach(el => observer.observe(el));
}

function animateCounter(el) {
  const target = parseInt(el.getAttribute('data-target'));
  const duration = 2000;
  const startTime = performance.now();

  function easeOutQuart(t) {
    return 1 - Math.pow(1 - t, 4);
  }

  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const easedProgress = easeOutQuart(progress);
    const current = Math.round(easedProgress * target);

    if (target >= 10000) {
      el.textContent = current.toLocaleString('en-IN') + '+';
    } else {
      el.textContent = current + '+';
    }

    if (progress < 1) {
      requestAnimationFrame(update);
    }
  }

  requestAnimationFrame(update);
}

// ============================================
// DESTINATION TABS
// ============================================
function initDestinationTabs() {
  const tabs = document.querySelectorAll('.tab-btn');
  const panels = document.querySelectorAll('.dest-panel');

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const target = tab.getAttribute('data-tab');

      // Update active tab
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      // Update active panel
      panels.forEach(panel => {
        panel.classList.remove('active');
        if (panel.id === `panel-${target}`) {
          panel.classList.add('active');
          // Re-trigger reveal animations for newly visible cards
          panel.querySelectorAll('.reveal').forEach(el => {
            el.classList.remove('visible');
            // Small delay to allow re-observation
            requestAnimationFrame(() => {
              el.classList.add('visible');
            });
          });
        }
      });
    });
  });
}

// ============================================
// SET MIN DATE — Prevent past dates
// ============================================
function setMinDate() {
  const dateInput = document.getElementById('travelDate');
  if (dateInput) {
    const today = new Date().toISOString().split('T')[0];
    dateInput.setAttribute('min', today);
  }
}

// ============================================
// ENQUIRY FORM — Validation + Firebase
// ============================================
function initEnquiryForm() {
  const form = document.getElementById('enquiryForm');
  const submitBtn = document.getElementById('submitBtn');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    // Clear previous errors
    form.querySelectorAll('.error').forEach(el => el.classList.remove('error'));

    // Validate
    let isValid = true;
    const fields = {
      fullName: { required: true, minLength: 2 },
      email: { required: true, pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/ },
      phone: { required: true, pattern: /^[+]?[\d\s-]{7,15}$/ }
    };

    for (const [fieldName, rules] of Object.entries(fields)) {
      const input = document.getElementById(fieldName);
      const value = input.value.trim();

      if (rules.required && !value) {
        input.classList.add('error');
        isValid = false;
      } else if (rules.minLength && value.length < rules.minLength) {
        input.classList.add('error');
        isValid = false;
      } else if (rules.pattern && !rules.pattern.test(value)) {
        input.classList.add('error');
        isValid = false;
      }
    }

    if (!isValid) {
      // Focus first error field
      const firstError = form.querySelector('.error');
      if (firstError) firstError.focus();
      return;
    }

    // Collect form data
    const formData = {
      name: document.getElementById('fullName').value.trim(),
      email: document.getElementById('email').value.trim(),
      phone: document.getElementById('phone').value.trim(),
      destination: document.getElementById('destination').value || 'Not specified',
      travelDate: document.getElementById('travelDate').value || 'Not specified',
      travelers: document.getElementById('travelers').value,
      message: document.getElementById('message').value.trim() || 'No message',
      createdAt: new Date().toISOString(),
      status: 'new'
    };

    // Submit
    submitBtn.classList.add('loading');
    submitBtn.disabled = true;

    try {
      if (db) {
        // Save to Firebase Firestore
        await db.collection('enquiries').add({
          ...formData,
          createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        console.log('✅ Enquiry saved to Firestore');
      } else {
        // Demo mode — log to console
        console.log('📋 Enquiry (Demo Mode):', formData);
        // Simulate network delay
        await new Promise(resolve => setTimeout(resolve, 1000));
      }

      // Success
      showToast('success');
      form.reset();
      document.getElementById('travelers').value = '2';
    } catch (error) {
      console.error('❌ Error submitting enquiry:', error);
      showToast('error');
    } finally {
      submitBtn.classList.remove('loading');
      submitBtn.disabled = false;
    }
  });

  // Real-time validation: remove error on input
  form.querySelectorAll('input, select, textarea').forEach(input => {
    input.addEventListener('input', () => {
      input.classList.remove('error');
    });
  });
}

// ============================================
// TOAST NOTIFICATIONS
// ============================================
function showToast(type) {
  const toast = document.getElementById(type === 'success' ? 'toastSuccess' : 'toastError');

  toast.classList.add('show');

  setTimeout(() => {
    toast.classList.remove('show');
  }, 4000);
}

// ============================================
// HERO SLIDER
// ============================================
function initHeroSlider() {
  const slides = document.querySelectorAll('.hero-slide');
  if (slides.length === 0) return;
  let currentSlide = 0;
  setInterval(() => {
    slides[currentSlide].classList.remove('active');
    currentSlide = (currentSlide + 1) % slides.length;
    slides[currentSlide].classList.add('active');
  }, 4000);
}


